# jade-smrt

This is a strategy for counting:
- JADE and sJADE token held on BSC
- SMRT and SMRTR token held on Avalanche c-chain (including the ones in
the SMRTR/AVAX pool), which are then weighted by the price_SMRT/price_JADE
and price_SMRTR/price_JADE