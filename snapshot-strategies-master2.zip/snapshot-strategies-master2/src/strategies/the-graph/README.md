# The Graph base strategy logic

> **Notice**
> 
> This is a helper library. It is not meant to be used in a standalone fashion and does not conform with the shape of a strategy function. 
> 
> It will be used internally by the actual strategies of The Graph.