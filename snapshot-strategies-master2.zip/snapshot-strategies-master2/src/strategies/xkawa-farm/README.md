# xkawa-farm

Returns voting power based on xKawa token held and stacked in the xKawa Single-side farm, as well as associated pending xKawa reward