# tech-quadratic-ranked-choice

This strategy was create to allow TECH combine ranked choice voting with quadratic strategy. This strategy will apply squared root to the balance of the voters, making the power of decision spread to the edges.

Here is an example of parameters:

```json
{
  "address": "0x799844141C2627bD195c89c3A0c71341d0314c55",
  "symbol": "TECH",
  "decimals": 18
}
```
