# Thales Strategy

A strategy for Thales governance.
The voting score is based on the THALES staking amount.

## Examples

Here is an example of parameters:

```JSON
{
  "symbol": "THALES",
  "decimals": 18
}
```
