# Posichain Total Balance Strategy

Calculates vote of validators based on their balance, plus total staking (includes self stake and total balance delegated to them).
