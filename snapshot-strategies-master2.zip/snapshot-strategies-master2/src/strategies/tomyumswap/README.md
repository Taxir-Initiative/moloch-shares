# Contract Call Strategy

Fetches [TOMYUM](https://bscscan.com/address/0xa8777a7855cc5e5d4994d890eaad369050a9ff47) balance from the following sources:

- Wallet
- TOMYUM-BNB LP Farm
- TOMYUM Pool
- TOMYUM Vault
- Pools that were active at the time of the snapshot
