# ve-balance-of-at-nft

This returns the voting power of the voters for his ve NFTs by calling `balanceOfAtNFT` on the contract.

Here is an example of parameters:

```json
{
  "address": "0xc8034b3dF18Ea4d607E86D6b6Bf23E2A8Ed70F89",
  "symbol": "vedcMST",
  "decimals": 18
}
```