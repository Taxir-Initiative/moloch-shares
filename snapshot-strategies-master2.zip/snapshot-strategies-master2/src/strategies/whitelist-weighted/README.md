# Whitelist Weighted Strategy

This strategy returns weighted votes for addresses matching a static whitelist.
