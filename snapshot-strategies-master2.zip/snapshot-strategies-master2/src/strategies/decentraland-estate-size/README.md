# Decentraland Wearable Rarity

This strategy allows users to calculate the total amount of Decentraland lands in estates and apply a multiplier to the result.

## Example

The parameters should look like this:

```json
{
    "symbol": "ESTATE",
    "multiplier": 2000
}
```
