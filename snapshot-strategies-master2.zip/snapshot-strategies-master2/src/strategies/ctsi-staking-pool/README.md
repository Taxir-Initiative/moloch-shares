# ctsi-staking-pool

This strategy implements the rules of CTSI Staking through Staking Pools, returning the staked balance of the voters in all pools they stake to.

There are no parameters to configure.

Direct stakers or pool operators are not accounted in this strategy. For those use strategy `ctsi-staking`.
