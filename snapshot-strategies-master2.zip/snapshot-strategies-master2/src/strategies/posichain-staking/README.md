# Posichain Staking Strategy

Calculates vote of validators based on the total staking (includes self stake and total balance delegated to them).
