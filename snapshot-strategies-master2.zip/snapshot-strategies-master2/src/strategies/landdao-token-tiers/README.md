# erc721 with tokenid scattered weights

This strategy allows you to weight erc721's with different values from ipfs.

Here is an example of parameters:

```json
{
  "address": "0xEa25e2b3E35c67876957EE00a28Cd912ff113F54",
  "symbol": "LAND",
  "tokenWeightIPFS": "QmXrDNrjX8xZu9bdNA1iiW7Ee12RADQFwwhCeLQnwqG2TJ"
}
```
