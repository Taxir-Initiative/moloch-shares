# honeyswap

Here is an example of parameters:

```json
{
  "address": "0xe91d153e0b41518a2ce8dd3d7944fa863463a97d",
  "useStakedBalances": "true"
}
```

- *address* - the underlying token
- *useStakedBalances* - if **true** it will also return the token balances from the HoneyFarm pools
