# rocketpool-node-operator

This is a strategy for staking node operators, it returns the half square rooted node effective stake balance given a node address.

Here is an example of parameters:

```json
{
  "address": "0xD33526068D116cE69F19A9ee46F0bd304F21A51f",
  "symbol": "RPL",
  "decimals": 18
}
```
