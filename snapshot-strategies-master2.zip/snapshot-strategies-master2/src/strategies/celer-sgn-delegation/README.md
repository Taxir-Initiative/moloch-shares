# celer-sgn-delegation

Strategy to count the number of CELR tokens delegated to SGN validators.

Here is an example of parameters:

```json
{
  "v1StakingAddress": "0x5216db4d4cb22d1ba38866867c38d8e862974e82",
  "v2StakingViewerAddress": "0x5803457E3074E727FA7F9aED60454bf2F127853b"
}
```
