# Proxy ERC1155

This allows for a Proxy wallet to map to multiple wallets owned by the user.

You would use the exact same parameters as erc1155-balance-of, but the signing wallet is now the proxy wallet.
