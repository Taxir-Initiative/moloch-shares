# Contract call strategy

Allows to get Voting power from ZRX governer contract + erc20 balance

## Strategy Parameters
