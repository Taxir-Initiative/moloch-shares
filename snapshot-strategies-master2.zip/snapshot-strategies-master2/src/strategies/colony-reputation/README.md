# colony-reputation

Uses reputation in a colony as voting power.

Here is an example of parameters:

```json
{
  "colonyAddress": "0x51A1fC3f8B1D46e66691C1a7F1A84C9b863dE8c2",
  "colonyNetworkAddress": "0x78163f593D1Fa151B4B7cacD146586aD2b686294",
  "domainId": 1
}
```
