# Sunrise Gaming Staking Token

This strategy returns balances of the underlying token in Sunrise Staking pools

Here is an example of parameters:

```json
{
  "symbol": "SUNC",
  "decimals": 18,
  "tokenAddress": "0x692accdd8b86692427e0aa4752ae917df01cc56f",
  "stakingAddress": "0x7dbE40ac6bB41A5FE4Fa2C74f31d7DEFBC793B58",
  "poolIndex": 0
}
```