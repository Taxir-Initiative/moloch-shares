# selfswap

Fetches [SELF](https://bscscan.com/address/0x7a364484303b38bce7b0ab60a20da8f2f4370129) balance from the following sources:

- Wallet
- SELF-BNB LP Farm
- SELF Pool
- SELF Vault
- Pools that were active at the time of the snapshot
