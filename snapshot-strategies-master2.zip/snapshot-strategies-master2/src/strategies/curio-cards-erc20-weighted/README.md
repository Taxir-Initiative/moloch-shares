# Curio Cards ERC20 Weighted Voting Strategy

Curio cards are a pseudo-NFT that predates the erc721 and erc1155 specifications. Each card is implemented as an erc20 with a max supply between 100-2000 tokens.

This strategy weights the vote according to the holdings of each card and relative scarcity of each card.
