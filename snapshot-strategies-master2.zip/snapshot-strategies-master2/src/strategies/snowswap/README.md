Snowswap

Checks for the number of SNOW's staked in Frosty’s pool (https://etherscan.io/address/0x7d2c8b58032844f222e2c80219975805dce1921c) and adds it to the balance of the voters FLAME ERC20 token

Here is an example of parameters:

{
    "address": "0xfe9A29aB92522D14Fc65880d817214261D8479AE",
    "symbol": "SNOW",
    "decimals": 18,
    "snowStakingAddress": "0x7d2c8b58032844f222e2c80219975805dce1921c"
}
