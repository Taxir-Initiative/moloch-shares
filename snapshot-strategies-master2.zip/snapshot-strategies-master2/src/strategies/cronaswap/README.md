# CronaSwap

This is the most common strategy, it returns the balances of the voters for a balances CRONA token
in CronaSwap project(pools, farms, Liquidity, token).

Here is an example of parameters:
```json
[
  {
    "name": "Example query CronaSwap",
    "strategy": {
      "name": "cronaswap",
      "params": {
        "address": "0xadbd1231fb360047525BEdF962581F3eee7b49fe",
        "masterChef": "0x77ea4a4cF9F77A034E4291E8f457Af7772c2B254",
        "autoCrona": "0xDf3EBc46F283eF9bdD149Bb24c9b201a70d59389",
        "cronaLPs": [
          {
            "address": "0xeD75347fFBe08d5cce4858C70Df4dB4Bbe8532a0",
            "pid": 1
          },
          {
            "address": "0x482E0eEb877091cfca439D131321bDE23ddf9bB5",
            "pid": 13
          },
          {
            "address": "0x0427F9C304b0028f67A5fD61ffdD613186c1894B",
            "pid": 14
          }
        ],
        "symbol": "CRONA",
        "decimals": 18
      }
    },
    "network": "25",
    "addresses": [
      "0xd758B37Aff75F8Ee847D606fcEfE7BD18C8ed029",
      "0xB6E6d031db616cF8aC338293dC2ecFa0F01C55EC"
    ],
    "snapshot": 599576
  }
]


```
