# Giveth xDai balance

This strategy sums up all the GIV on xDai, including the ones that are staked in Honeyswap pools, Sushiswap pools, and single staked on GIV pool.

Here is an example of parameters:

```json
{
  "symbol": "GIV",
  "decimals": 18
}
```
