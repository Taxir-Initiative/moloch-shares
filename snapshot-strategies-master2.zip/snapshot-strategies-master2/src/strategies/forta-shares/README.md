# forta-shares

This strategy calculates the voting power of the FORT shares owned by an address. This strategy requires no parameters.