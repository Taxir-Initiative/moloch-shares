# sd-boost

This strategy is used by StakeDAO to vote with sdToken with veSDT voting boost
Here is an example of parameters:

```json
{
  "sdToken": "0x402F878BDd1f5C66FdAF0fabaBcF74741B68ac36",
  "veToken": "0xc8418aF6358FFddA74e09Ca9CC3Fe03Ca6aDC5b0",
  "lockerToken": "0xCd3a267DE09196C48bbB1d9e842D7D7645cE448f",
  "gauge": "0xF3C6e8fbB946260e8c2a55d48a5e01C82fD63106",
  "symbol": "sdToken",
  "decimals": 18
}
```
