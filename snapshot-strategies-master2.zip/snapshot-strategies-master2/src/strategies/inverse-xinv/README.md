# inverse-xinv

This is a strategy for counting staked INV balance inside of anchor. Referred to as xINV. 
Here is an example of parameters:

```json
{
  "symbol": "xINV",
  "decimals": 18
}
```
