# meebitsdao

This strategy return the if the voter has an activated Founder's Token.

Here is an example of parameters:

```json
{
  "address": "0xc34cbca32e355636c7f52dd8beab0af2396ebd79",
  "symbol": "MFND",
  "apiUrl": "https://api.meebitsdao.com/user/token_status/",
  "startingTokenId": 1,
  "endingTokenId": 200
}
```
