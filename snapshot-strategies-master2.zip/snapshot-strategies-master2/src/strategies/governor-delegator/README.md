# governor-delegator

Allows users to vote with their token balance, if the user delegated their voting power to a particular delegate address

## Params

```JSON
{
  "delegate": "0xb8c2c29ee19d8307cb7255e1cd9cbde883a267d5",
  "address": "0xc18360217d8f7ab5e7c516566761ea12ce7f9d72",
  "symbol": "ENS",
  "decimals": 18
}
```
