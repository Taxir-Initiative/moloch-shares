# minto-balance-of-all

This is the minto strategy, it returns sum the balances of the voters from minto erc20, minto staking, minto staking.

Here is an example of parameters:

```json
{
  "address": "0x410a56541bD912F9B60943fcB344f1E3D6F09567",
  "symbol": "BTCMT",
  "decimals": 18,
  "stakingAddress": "0x78ae303182FCA96A4629A78Ee13235e6525EbcFb",
  "autoStakingAddress": "0xE751ffdC2a684EEbcaB9Dc95fEe05c083F963Bf1"
}
```
