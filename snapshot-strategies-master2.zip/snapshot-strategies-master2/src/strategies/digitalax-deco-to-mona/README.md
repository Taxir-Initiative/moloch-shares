# DIGITALAX DECO to MONA conversion

This is the DIGITALAX DECO to MONA conversion for voting purposes

Here is an example of parameters:

```json
{
  "symbol": "MONA",
  "address": "0x200f9621cbce6ed740071ba34fde85ee03f2e113"
}
```


